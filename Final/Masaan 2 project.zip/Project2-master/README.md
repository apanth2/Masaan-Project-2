# Project2
Starting point for Project 2, CS 428 Virtual and Augmented Reality, Fall 2019 at the Univesity of Illinois at Chicago,
Written by Andy Johnson - ajohnson@uic.edu
#
The Project makes use of VRTK and will have various other assets referenced here once the starting point is complete
